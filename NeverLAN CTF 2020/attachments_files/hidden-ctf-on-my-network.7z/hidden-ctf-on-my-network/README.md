# Wednesday [61 pts]

**Solves:** 7

## Description
Wireshark?

-----

So, I have a little CTF challenge I've been running on my home network for about a year now. No one has noticed it and I doubt anyone ever will.... Until today!

I grabbed a hak5 plunderbug and recorded the traffic of a cheap HP machine booting up for the first time on my network. Can you solve the CTF challenge I leave for my guests?
